<?php

namespace Example\Services;

abstract class ApiTypes
{
    const Admin = 'Admin';
    const Click = 'Click';
    const Monitor = 'Monitor';
    const Rooms = 'Rooms';
    const eSignature = 'eSignature';
}